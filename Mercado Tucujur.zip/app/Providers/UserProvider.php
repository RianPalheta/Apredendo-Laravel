<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class UserProvider extends ServiceProvider
{
    public function isValidadeUser($data = [])
    {

        return $data;
    }
}
