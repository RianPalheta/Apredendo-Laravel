<?php

namespace App\Http\Controllers\Admin\Api;

use App\Http\Controllers\Controller;
use App\Models\Categorie;
use Illuminate\Http\Request;

class CategoryApiController extends Controller
{
    public function get_categories(Request $request)
    {
        $search['content'] = $request->input('search');

        $qt = intval($request->input('qt', 10));
        $categories = Categorie::where('name', 'like', '%'.$search['content'].'%')
            ->orderByDesc('id')
            ->paginate($qt);

        $json = json_encode($categories);
        $array = json_decode($json, true);
        $data = $array['data'];
        unset($array['data']);

        $pre = [];
        foreach($data as $item) {
            $item['subs'] = [];
            $pre[$item['id']] = $item;
        }
        while($this->stillNeed($pre)) {
            $this->organizeCategory($pre);
        }
        $array['data'] = $pre;

        echo json_encode($array);
        return;
    }

    public function store(Request $request)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }

    private function organizeCategory(&$array = []) {
        foreach($array as $id => $item) {
            if(!empty($item['sub'])) {
                $array[$item['sub']]['subs'][$item['id']] = $item;
                unset($array[$id]);
                break;
            }
        }
    }

    private function stillNeed($array = []) {
        foreach($array as $item) {
            if(!empty($item['sub'])) {
                return true;
            }
        }
        return false;
    }
}
