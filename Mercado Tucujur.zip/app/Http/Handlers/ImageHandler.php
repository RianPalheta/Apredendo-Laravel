<?php

namespace App\Http\Handlers;

use Illuminate\Http\Request;

class ImageHandler {
    static public function encodeImg($teste) {
        return $teste;
    }
}
