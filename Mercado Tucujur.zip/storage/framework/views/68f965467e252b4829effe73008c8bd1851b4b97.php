<?php $__env->startSection('title', 'Editar Página'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar página</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/toastr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        const images_upload_url = "<?php echo e(route('imageupload')); ?>";
        const url_edit = "<?php echo e(route('pages.update', [1])); ?>";
        const id = "<?php echo e($page->id); ?>";
    </script>
    <script src="https://cdn.tiny.cloud/1/b6hnb08gw7mg8f83eozwq9gxez89dh47vamxf49vhzugj3s0/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
    <script src="<?php echo e(asset('assets/js/plugins/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/painel.pages.edit.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form id="page-edit">
                <div class="form-group">
                    <label for="title">
                        <font style="vertical-align: inherit;">
                            <font style="vertical-align: inherit;">Título <span style="color: #DC3545">*</span></font>
                        </font>
                    </label>
                    <div class="input-group">
                        <input type="text" name="title" class="form-control" id="title" value="<?php echo e($page->title); ?>" placeholder="Digite um título para página">
                    </div>
                </div>

                <div class="form-group">
                    <textarea name="body" class="form-control body-field"><?php echo e($page->body); ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary float-right" id="submit_add">
                    <font style="vertical-align: inherit;">
                        <font style="vertical-align: inherit;">Salvar</font>
                    </font>
                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Mercado Tucujur\resources\views/admin/Pages/edit.blade.php ENDPATH**/ ?>