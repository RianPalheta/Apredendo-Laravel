<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('js'); ?>
    <script>
        const url = "<?php echo e(route('auth.login')); ?>"
        const painel = "<?php echo e(route('painel')); ?>"
    </script>
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/painel.login.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/rian/Dados/wamp/www/Mercado Tucujur/resources/views/admin/login.blade.php ENDPATH**/ ?>