<?php $__env->startSection('title', 'Editar Usuário'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Usuário</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/dropzone.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/toastr.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        const url_cep = "<?php echo e(route('cep')); ?>";
        const assets = "<?php echo e(asset('media/users')); ?>";
        const url_update = "<?php echo e(route('users.update', [$user->id])); ?>";
    </script>
    <script src="<?php echo e(asset('assets/js/plugins/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/dropzone.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/imask.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/painel.users.edit.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="card card-primary card-outline">
                <div class="card-body box-profile">
                    <div class="text-center">
                        <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset('media/users/'.$user->avatar)); ?>" />
                    </div>
                </div>
                <div class="card-footer">
                    <form action="<?php echo e(route('users.update', [$user->id])); ?>" class="dropzone dz-clickable" id="photo_user">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="dz-default dz-message">
                            <span>
                                Coloque sua foto de perfil aqui.
                            </span>
                        </div>
                        <div class="fallback">
                            <input type="file" name="fileToUpload" accept="image/*">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <ul class="nav nav-pills">
                        <li class="nav-item">
                            <a class="nav-link active" href="#info" data-toggle="tab">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;">Detalhes</font>
                                </font>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#address" data-toggle="tab">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;">Endereço</font>
                                </font>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <form id="user-edit">
                        <div class="tab-content">
                            <div class="tab-pane active" id="info">
                                <div class="form-group">
                                    <label for="name">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">Nome</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control" id="name" placeholder="Digite seu nome">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="far fa-user"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="email">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">Email</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control" id="email" placeholder="Digite seu email">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="far fa-envelope"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="telephone">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">Telefone</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" name="telephone" value="<?php echo e($user->telephone); ?>" class="form-control" id="telephone" placeholder="(___) _____-____">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-mobile-alt"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="birthday">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">Data de nascimento</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" name="birthday" value="<?php echo e($user->birthday); ?>" class="form-control" id="birthday" placeholder="__/__/____">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="far fa-calendar-alt"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="cpf">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">CPF</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" name="cpf" value="<?php echo e($user->cpf); ?>" class="form-control" id="cpf" placeholder="___.___.___-__">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="far fa-address-card"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="password">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">Senha</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="password" name="password" class="form-control" id="password" placeholder="Digite uma senha">
                                        <div class="input-group-prepend pass" style="cursor: pointer">
                                            <span class="input-group-text">
                                                <i class="far fa-eye"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="password_confirmation">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">Confirme sua senha</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="password" name="password_confirmation" class="form-control" id="password_confirmation" placeholder="Confirme sua nova senha">
                                        <div class="input-group-prepend pass" style="cursor: pointer">
                                            <span class="input-group-text">
                                                <i class="far fa-eye"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="address">
                                <div class="form-group">
                                    <label for="cep">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">CEP</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" name="cep" value="<?php echo e($user->cep); ?>" class="form-control" id="cep" placeholder="__.___-__">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-globe-americas"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="uf">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">UF</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" name="uf" value="<?php echo e($user->uf); ?>" class="form-control" id="uf" placeholder="Unidade Federativa (Cidade)">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="far fa-map"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="city">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">Cidade</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" name="city" value="<?php echo e($user->city); ?>" class="form-control" id="city" placeholder="Sua cidade">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="far fa-building"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="district">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">Bairro</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" name="district" value="<?php echo e($user->district); ?>" class="form-control" id="district" placeholder="Seu bairro">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-map-marker-alt"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="road">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">Rua</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" name="road" value="<?php echo e($user->road); ?>" class="form-control" id="road" placeholder="Sua rua">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-map-signs"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="number_home">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">Número</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" name="number_home" value="<?php echo e($user->number_home); ?>" class="form-control" id="number_home" placeholder="Número da sua residência">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="fas fa-home"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="complement">
                                        <font style="vertical-align: inherit;">
                                            <font style="vertical-align: inherit;">Complemento</font>
                                        </font>
                                    </label>
                                    <div class="input-group">
                                        <textarea class="form-control" name="complement" rows="3" spellcheck="false" data-gramm="false"><?php echo e($user->complement); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary float-right">
                            <font style="vertical-align: inherit;">
                                <font style="vertical-align: inherit;">Salvar</font>
                            </font>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\Mercado Tucujur\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>