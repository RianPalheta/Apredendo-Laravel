<?php $__env->startSection('title', 'Cadastro'); ?>

<?php $__env->startSection('js'); ?>
    <script>
        const url = "<?php echo e(route('auth.register')); ?>"
        const painel = "<?php echo e(route('painel')); ?>"
    </script>
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.3.0/jquery.form.min.js" integrity="sha384-qlmct0AOBiA2VPZkMY3+2WqkHtIQ9lSdAsAn5RUJD/3vA5MKDgSGcdmIv4ycVxyn" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('assets/js/painel.login.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::auth.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Mercado Tucujur\resources\views/admin/register.blade.php ENDPATH**/ ?>