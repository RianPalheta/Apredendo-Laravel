<?php $__env->startSection('title', 'Usuários'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Usuários</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>

                </tbody>
            </table>
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script>
        const url = "<?php echo e(route('getUsers')); ?>"
        $(function() {
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url,
            type:'POST',
            data:'getUsers',
            dataType:'JSON',
            beforeSend: function() {
                // $('tbody').html("Carregando...")
            },
            success:function(response) {
                response.map(i => {
                    let table = `
                    <tr>
                        <td>${i.id}</td>
                        <td>${i.name}</td>
                        <td>${i.email}</td>
                        <td>
                            <a title="Editar" href="" class="btn btn-sm btn-info"><i class="fas fa-user-edit"></i></a>
                            <form class="d-inline" action="" method="POST" onsubmit="return confirm('Tem certeza que deseja excluir esse usuário?')">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button title="Deletar" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    `
                    $('tbody').append(table)
                })
            }
        })
    })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp\www\Mercado Tucujur\resources\views/admin/users/index.blade.php ENDPATH**/ ?>